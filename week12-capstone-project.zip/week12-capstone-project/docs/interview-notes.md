# Interview talking points
- **30-second pitch:** "I built TaskFlow, a FastAPI project-management backend with JWT auth, Postgres, real-time WebSocket updates, 96% test coverage, Docker and CI."
- **Hard problem:** real-time broadcast tied to REST mutations; tested with TestClient WebSocket.
- **Trade-off you can defend:** in-memory hub vs Redis pub/sub (simplicity now, horizontal scaling later).
- **Be ready for:** why 404 vs 403, JWT pitfalls, N+1 queries, index choice, sync vs async DB access, how to add Celery.
- **Resume bullet:** Built a FastAPI/PostgreSQL task-management API with JWT auth and WebSocket live updates; 96% test coverage, Dockerised with GitHub Actions CI.
