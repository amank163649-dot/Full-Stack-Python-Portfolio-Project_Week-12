# Architecture

```
Client (React, planned)  ──REST──▶  FastAPI routers (api/)
        │                               │  Depends(current_user) → JWT check
        └────WebSocket──▶ realtime.ProjectHub ◀── broadcast on create/update/delete
                                        │
                              SQLAlchemy models ──▶ PostgreSQL
```

## Key decisions
- **FastAPI**: async support, automatic OpenAPI docs, Pydantic validation.
- **Composite index** `(project_id, status)` on tasks: serves the main list/filter query.
- **Per-project WebSocket rooms**: clients only receive events for projects they own.
- **404 for foreign resources**: avoids leaking which IDs exist.
- **Known limitation**: the in-memory hub works for a single process; scaling out needs Redis pub/sub.
- **Known limitation**: sync DB calls inside async handlers; move to async SQLAlchemy under load.
