import pytest
from fastapi.testclient import TestClient
from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker
from sqlalchemy.pool import StaticPool

import src.api.tasks as tasks_mod
from src import database
from src.database import Base, get_db
from src.main import app

engine = create_engine("sqlite://", connect_args={"check_same_thread": False}, poolclass=StaticPool)
TestSession = sessionmaker(bind=engine, expire_on_commit=False)
database.SessionLocal = TestSession  # used by the WebSocket endpoint

tasks_mod.SessionLocal = TestSession


def override_db():
    db = TestSession()
    try:
        yield db
    finally:
        db.close()


app.dependency_overrides[get_db] = override_db


@pytest.fixture()
def client():
    Base.metadata.drop_all(engine)
    Base.metadata.create_all(engine)
    return TestClient(app)


def signup(client, email="a@example.com"):
    r = client.post("/api/auth/register", json={"email": email, "password": "password123"})
    assert r.status_code == 201
    return r.json()["access_token"], {"Authorization": f"Bearer {r.json()['access_token']}"}


def test_register_login_and_duplicate(client):
    signup(client)
    assert client.post("/api/auth/register", json={"email": "a@example.com", "password": "password123"}).status_code == 409
    assert client.post("/api/auth/login", json={"email": "a@example.com", "password": "password123"}).status_code == 200
    assert client.post("/api/auth/login", json={"email": "a@example.com", "password": "wrongpass1"}).status_code == 401


def test_requires_auth(client):
    assert client.get("/api/projects").status_code == 401


def test_task_crud_filter_and_pagination(client):
    _, h = signup(client)
    pid = client.post("/api/projects", json={"name": "P"}, headers=h).json()["id"]
    for i in range(3):
        client.post(f"/api/projects/{pid}/tasks", json={"title": f"t{i}"}, headers=h)
    tid = client.get(f"/api/projects/{pid}/tasks", headers=h).json()[0]["id"]
    assert client.patch(f"/api/tasks/{tid}", json={"status": "done"}, headers=h).json()["status"] == "done"
    assert len(client.get(f"/api/projects/{pid}/tasks?status=done", headers=h).json()) == 1
    assert len(client.get(f"/api/projects/{pid}/tasks?limit=2", headers=h).json()) == 2
    assert client.delete(f"/api/tasks/{tid}", headers=h).status_code == 204
    assert client.patch(f"/api/tasks/{tid}", json={"status": "bogus"}, headers=h).status_code in (404, 422)


def test_users_cannot_access_others_projects(client):
    _, h1 = signup(client, "a@example.com")
    _, h2 = signup(client, "b@example.com")
    pid = client.post("/api/projects", json={"name": "P"}, headers=h1).json()["id"]
    assert client.get(f"/api/projects/{pid}/tasks", headers=h2).status_code == 404


def test_websocket_receives_task_events(client):
    token, h = signup(client)
    pid = client.post("/api/projects", json={"name": "P"}, headers=h).json()["id"]
    with client.websocket_connect(f"/api/ws/projects/{pid}?token={token}") as ws:
        client.post(f"/api/projects/{pid}/tasks", json={"title": "live"}, headers=h)
        msg = ws.receive_json()
        assert msg["event"] == "task.created" and msg["task"]["title"] == "live"


def test_websocket_rejects_bad_token(client):
    _, h = signup(client)
    pid = client.post("/api/projects", json={"name": "P"}, headers=h).json()["id"]
    with pytest.raises(Exception):
        with client.websocket_connect(f"/api/ws/projects/{pid}?token=bad"):
            pass
