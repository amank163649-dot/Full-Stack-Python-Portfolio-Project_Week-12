from collections import defaultdict

from fastapi import WebSocket


class ProjectHub:
    """Tracks WebSocket connections per project and broadcasts events."""

    def __init__(self):
        self.rooms: dict[int, set[WebSocket]] = defaultdict(set)

    async def join(self, project_id: int, ws: WebSocket):
        await ws.accept()
        self.rooms[project_id].add(ws)

    def leave(self, project_id: int, ws: WebSocket):
        self.rooms[project_id].discard(ws)

    async def broadcast(self, project_id: int, event: dict):
        for ws in list(self.rooms[project_id]):
            try:
                await ws.send_json(event)
            except Exception:
                self.leave(project_id, ws)


hub = ProjectHub()
