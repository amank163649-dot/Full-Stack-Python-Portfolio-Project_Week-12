from fastapi import APIRouter, Depends, HTTPException, Query, WebSocket, WebSocketDisconnect
from sqlalchemy import select
from sqlalchemy.orm import Session

from src.database import SessionLocal, get_db
from src.models import Project, Task, User
from src.realtime import hub
from src.schemas import ProjectIn, ProjectOut, Status, TaskIn, TaskOut, TaskUpdate
from src.security import current_user, decode_token

router = APIRouter(prefix="/api", tags=["projects & tasks"])


def _own_project(db: Session, project_id: int, user: User) -> Project:
    project = db.get(Project, project_id)
    # 404 (not 403) so other users' project IDs aren't discoverable
    if not project or project.owner_id != user.id:
        raise HTTPException(404, "Project not found")
    return project


@router.post("/projects", response_model=ProjectOut, status_code=201)
def create_project(body: ProjectIn, db: Session = Depends(get_db), user: User = Depends(current_user)):
    project = Project(name=body.name, owner_id=user.id)
    db.add(project)
    db.commit()
    return project


@router.get("/projects", response_model=list[ProjectOut])
def list_projects(db: Session = Depends(get_db), user: User = Depends(current_user)):
    return db.scalars(select(Project).where(Project.owner_id == user.id)).all()


@router.post("/projects/{project_id}/tasks", response_model=TaskOut, status_code=201)
async def create_task(project_id: int, body: TaskIn, db: Session = Depends(get_db), user: User = Depends(current_user)):
    _own_project(db, project_id, user)
    task = Task(project_id=project_id, **body.model_dump())
    db.add(task)
    db.commit()
    out = TaskOut.model_validate(task)
    await hub.broadcast(project_id, {"event": "task.created", "task": out.model_dump()})
    return out


@router.get("/projects/{project_id}/tasks", response_model=list[TaskOut])
def list_tasks(
    project_id: int,
    status: Status | None = None,
    limit: int = Query(20, ge=1, le=100),
    offset: int = Query(0, ge=0),
    db: Session = Depends(get_db),
    user: User = Depends(current_user),
):
    _own_project(db, project_id, user)
    q = select(Task).where(Task.project_id == project_id)
    if status:
        q = q.where(Task.status == status)
    return db.scalars(q.order_by(Task.id).limit(limit).offset(offset)).all()


@router.patch("/tasks/{task_id}", response_model=TaskOut)
async def update_task(task_id: int, body: TaskUpdate, db: Session = Depends(get_db), user: User = Depends(current_user)):
    task = db.get(Task, task_id)
    if not task:
        raise HTTPException(404, "Task not found")
    _own_project(db, task.project_id, user)
    for field, value in body.model_dump(exclude_unset=True).items():
        setattr(task, field, value)
    db.commit()
    out = TaskOut.model_validate(task)
    await hub.broadcast(task.project_id, {"event": "task.updated", "task": out.model_dump()})
    return out


@router.delete("/tasks/{task_id}", status_code=204)
async def delete_task(task_id: int, db: Session = Depends(get_db), user: User = Depends(current_user)):
    task = db.get(Task, task_id)
    if not task:
        raise HTTPException(404, "Task not found")
    _own_project(db, task.project_id, user)
    project_id = task.project_id
    db.delete(task)
    db.commit()
    await hub.broadcast(project_id, {"event": "task.deleted", "task_id": task_id})


@router.websocket("/ws/projects/{project_id}")
async def project_socket(ws: WebSocket, project_id: int, token: str = ""):
    user_id = decode_token(token)
    with SessionLocal() as db:
        project = db.get(Project, project_id)
        allowed = bool(user_id and project and project.owner_id == user_id)
    if not allowed:
        await ws.close(code=4401)
        return
    await hub.join(project_id, ws)
    try:
        while True:
            await ws.receive_text()  # keep-alive; server pushes events
    except WebSocketDisconnect:
        hub.leave(project_id, ws)
