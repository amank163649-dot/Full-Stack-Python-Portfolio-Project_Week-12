from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware

from src.api import auth, tasks
from src.database import Base, engine

Base.metadata.create_all(engine)  # swap for Alembic migrations in production

app = FastAPI(title="TaskFlow Pro API", version="0.1.0",
              description="Project & task management with real-time updates.")
app.add_middleware(CORSMiddleware, allow_origins=["http://localhost:5173"],
                   allow_methods=["*"], allow_headers=["*"])
app.include_router(auth.router)
app.include_router(tasks.router)


@app.get("/health", tags=["ops"])
def health():
    return {"status": "ok"}
